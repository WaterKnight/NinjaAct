=========================================================

Author: Republicola

Updater: Cookie Vashard

Source : http://www.wc3campaigns.com

Date : 08/25/2003

Download Type : Altered Model

Textures path : Units\Creeps\Ninja\Ninja.blp

Portrait/model path: Units\Creeps\Ninja\Ninja.mdx

Version: V1.02

Comments: 
A Ninja by Republicola. It is an amazing model where you can say "Coo! its so gosu!" =D
The original version didnt have a portrait cam and had some issues with the skin and the 
teamcolor (it glitched between skin and teamcolor). With Republicola's permission I have 
fixed the Ninja a little bit and gave him the Hero Blademasters Sword  =) 

Update:
Fixed the Blend Mode into Transparency so that weird see-through bug is fixed. Oddly enough, 
no-one complained about till I have figured out myself that there was one detail I overlooked. 
Also renamed it into mdx format (there was a error with winzip, it didnt import the file 
correctly with the file extension).

How to use:

Just import the skin with the usage of the TFT Import Manager. Then doubleclick the file and alter the path to
the above mentioned texture path.
                              
Just direct the model path to this model and its done. No need to add a portrait animation as there is simply none (merged into the model itself). Just use Import Manager in TFT and import in the map (remember the import model bug, you need to save and reload map in order to see the model)

=========================================================

-== http://www.wc3campaigns.com ==-
